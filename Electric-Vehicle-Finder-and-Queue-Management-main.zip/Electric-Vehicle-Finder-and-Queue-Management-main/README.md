# Electric-Vehicle-Finder-and-Queue-Management
Flutter Frontend

Firebase Backend

Google Map API

Features of Users:
  Charging Station find
  Reserve a Charging Slot
  
Features of Admin :
  Real time reservation view
  Manage Station detail

# Collaboraters
Umandi

Hansani
