package com.example.electric_vehicle

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
