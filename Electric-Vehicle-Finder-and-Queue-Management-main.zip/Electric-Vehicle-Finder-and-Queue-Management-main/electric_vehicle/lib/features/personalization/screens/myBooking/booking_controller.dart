import 'package:get/get.dart';

class MYBookingController extends GetxController {
  static MYBookingController get instance => Get.find();


}
